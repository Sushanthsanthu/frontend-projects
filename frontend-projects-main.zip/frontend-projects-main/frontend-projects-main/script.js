const searchButton = document.querySelector(".search-box button");
const searchInput = document.querySelector(".search-box input");

searchButton.addEventListener("click", function () {
    const searchValue = searchInput.value.trim();

    if (searchValue !== "") {
        alert("Searching for: " + searchValue);
    } else {
        alert("Please enter something to search.");
    }
});


// Hero slider buttons
const leftButton = document.querySelector(".left");
const rightButton = document.querySelector(".right");

const heroTexts = [
    "Fast shipping<br>on millions of items",
    "Discover amazing deals<br>every day",
    "Shop millions of products<br>with ease"
];

let currentSlide = 0;

function updateHero() {
    document.querySelector(".hero-content h1").innerHTML =
        heroTexts[currentSlide];
}

rightButton.addEventListener("click", function () {
    currentSlide++;

    if (currentSlide >= heroTexts.length) {
        currentSlide = 0;
    }

    updateHero();
});

leftButton.addEventListener("click", function () {
    currentSlide--;

    if (currentSlide < 0) {
        currentSlide = heroTexts.length - 1;
    }

    updateHero();
});